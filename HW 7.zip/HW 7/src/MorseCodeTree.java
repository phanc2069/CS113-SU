import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * MorseCodeTree : A BinaryTree, with Nodes of type Character to represent each letter of the English alphabet,
 * and a means of traversal to be used to decipher Morse code.
 *
 * @version 1.0
 */
public class MorseCodeTree extends BinaryTree<Character> {
    // TODO:
    // Build this class, which includes the parent BinaryTree implementation in addition to
    // the `translateFromMorseCode` and `readMorseCodeTree` methods. Documentation has been suggested for the former,
    // where said exceptional cases are to be handled according to the corresponding unit tests.

    private static Character[] dList;
    private String tempCode = "";
	
	public MorseCodeTree() {
		try {
			root = buildMorseCodeTree().root;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
    public String translateFromMorseCode(String morseCode) throws Exception {
    	ArrayList<String> separated = new ArrayList<String>(); //Separates string into individual codes (delimiter: space)
    	String output = "";
    	while (!morseCode.isEmpty()) {
    		int space = morseCode.indexOf(" ");
    		if(space == -1) {
    			separated.add(morseCode);
    			morseCode = "";
    		} else {
    			separated.add(morseCode.substring(0, space));
    			morseCode = morseCode.substring(space+1);
    		}
    		
    	}
    	for (String s : separated) {
    		Node<Character> temp = root;
    		String convert = s;
    		while (convert.length() > 1) {
    			if (convert.substring(0,1).equals("*")) {
    				temp = temp.left;
    			} else if (convert.substring(0,1).equals("-")) {
    				temp = temp.right;
    			} else {
    				throw new Exception();
    			}
    			convert = convert.substring(1);
    		}
    		if (convert.equals("*")) {
    			temp = temp.left;
    		} else if (convert.equals("-")) {
    			temp = temp.right;
    		} else throw new Exception();
    		output += temp.data;
    	}
        return output;
    }
    
    public boolean isLeaf() {
		return (root.left == null && root.right == null);
	}
    
    public static BinaryTree<Character> readMorseCodeTree(Character[] c, int i) {
    	if (i >= c.length) {
    		return null;
    	} else {
    		BinaryTree<Character> leftTree = readMorseCodeTree(c, 2 * i + 1);
			BinaryTree<Character> rightTree = readMorseCodeTree(c, 2 * i + 2);
			return new BinaryTree<Character>(c[i], leftTree, rightTree);
    	}
	}
    
    
    public BinaryTree<Character> buildMorseCodeTree() throws FileNotFoundException {
    	ArrayList<Character> dataList = new ArrayList<Character>();
    	dList = new Character[29];
    	File codeSheet = new File("src/Morse Code.txt");
    	Scanner arrayBuilder;
		try {
			arrayBuilder = new Scanner(codeSheet);
		} catch (FileNotFoundException e) {
			throw new FileNotFoundException();
		}
    	while(arrayBuilder.hasNextLine()) {
    		String data =  arrayBuilder.nextLine();
    		dataList.add(data.charAt(0));
    	}
    	arrayBuilder.close();
    	for (int i = 0; i < dataList.size(); i++) dList[i+1] = dataList.get(i); 
    	dList[0] = ' ';
    	return readMorseCodeTree(dList, 0);
    }
    
    public String TranslateToMC(String s) {
    	String output = "";
    	if (s.length() == 1) {
    		findLetter(s.charAt(0), root, "");
    		output = tempCode;
    	}
    	else {
    		char[] split = s.toCharArray();
    		for (char c: split) {
    			findLetter(c, root, "");
    			output += tempCode + " ";
    		}
    	}
    	return output;
    }
    
    public void findLetter(Character c, Node<Character> n, String output) {
    	if (n == root) {
    		findLetter(c, n.left, output+ "*");
    		findLetter(c, n.right, output+ "-");
    	}
    	else if (n == null) return;
    	else if (n.data.equals(c)) tempCode = output;
    	else {
    		findLetter(c, n.left, output+ "*");
    		findLetter(c, n.right, output+ "-");
    	}
    }
    
    
    public String toString() {
    	return super.toString();
    }

} // End of class MorseCodeTree