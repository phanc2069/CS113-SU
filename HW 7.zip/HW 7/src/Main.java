import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	
	private static ArrayList<String> arr = new ArrayList<>();
	
	private static String[] ALPHABET = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
	
	public static void printTable() {
		String joinSep = "\n-----------------------------------------------------------\n";
		System.out.print(joinSep);
		for (int i = 0; i < arr.size(); i++) {
			if (i == 0) System.out.printf("| " +ALPHABET[i] + " %-5s" + " | ", arr.get(i));
			else if (i == 4) System.out.printf(ALPHABET[i] + " %-4s" + " | ", arr.get(i));
			else if (i % 5 == 0) {
				System.out.printf(ALPHABET[i] + " %-5s" + "|%s| ", arr.get(i), joinSep);
			} else {
				System.out.printf(ALPHABET[i] + " %-5s" + " | ", arr.get(i));
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		MorseCodeTree t1 = new MorseCodeTree();
		for (String s: ALPHABET) arr.add(t1.TranslateToMC(s));
		Boolean con = true;
		Scanner keyboard = new Scanner(System.in); //USED FOR CREATING THE MENU IN CONSOLE
		Scanner keyboard2 = new Scanner(System.in);
		int choice = 0;
		
		while(con) {
			System.out.println("\nMAIN MENU\nWhat would you like to do?\n");
			System.out.println("\t1) Create a table \n \t2) Text File Decoding \n\t3) Decode Morse Code \n\t4) Exit \n");
			choice = keyboard.nextInt();
			
			if (choice == 1) {
				boolean choice1 = true;
				int con1;
				while (choice1) {
					System.out.println("Here is your table:\n");
					printTable();
					System.out.println("\nWould you like to exit?");
					System.out.println("\t1) Yes \n");
					con1 = keyboard.nextInt();
					if (con1 == 1) { choice1 = false; }
					else {
						boolean badinput = true;
						while (badinput) {
							System.out.println("\nWould you like to exit?");
							System.out.println("\t1) Yes \n");
							con1 = keyboard.nextInt();
							if (con1 == 1) {
								choice1 = false;
								badinput = false;
							}
						}
					}
				}
			}
			
			if (choice == 2) {
				boolean choice2 = true;
				int con2;
				while (choice2) {
					ArrayList<String> dataList = new ArrayList<>();
					System.out.println("Please type the name of your file");
					String input = keyboard2.nextLine();
					String filePath = "src/" + input;
					File codeSheet = new File(filePath);
					Scanner arrayBuilder;
					try {
						arrayBuilder = new Scanner(codeSheet);
					} catch (FileNotFoundException e) {
						throw new FileNotFoundException();
					}
			    	while(arrayBuilder.hasNextLine()) {
			    		String data =  arrayBuilder.nextLine();
			    		dataList.add(data);
			    	}
			    	arrayBuilder.close();
			    	
			    	for (String s: dataList) System.out.println(t1.translateFromMorseCode(s));
					System.out.println("\nWould you like to exit?");
					System.out.println("\t1) Yes \n");
					con2 = keyboard.nextInt();
					if (con2 == 1) {}
					else if (con2 == 2) {
						choice2 = false;
					}
					else {
						boolean badinput = true;
						while (badinput) {
							if (con2 == 1) {
								choice2 = false;
								badinput = false;
							}
						}
					}
				}
			}
			
			if (choice == 3) {
				keyboard.nextLine();
				boolean choice3 = true;
				int con3;
				while (choice3) {
					System.out.println("Please enter your Morse Code (separate each code with a space)");
					String input = keyboard2.nextLine();
					System.out.println("Here is the Morse Code");
					System.out.println(t1.translateFromMorseCode(input));
		
					System.out.println("\nWould you like to exit?");
					System.out.println("\t1) Yes \n");
					con3 = keyboard.nextInt();
					if (con3 == 1) {}
					else if (con3 == 2) {
						choice3 = false;
					}
					else {
						boolean badinput = true;
						while (badinput) {
							if (con3 == 1) {
								choice3 = false;
								badinput = false;
							}
						}
					}
				}
			}
			if (choice == 4) {
				keyboard.close();
				con = false;
			}
		}
		System.out.println("Shutting Down...");
	}
}

