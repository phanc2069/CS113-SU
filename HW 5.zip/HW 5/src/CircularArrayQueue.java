import java.util.*;

public class CircularArrayQueue<E> extends AbstractQueue<E> implements QueueInterface<E>{
	private int size = 0;
	private int capacity, front, rear;
	private E[] theData;
	
	public CircularArrayQueue (int initCapacity) {
		capacity = initCapacity;
		theData = (E[]) new Object[capacity];
		front = 0;
		rear = capacity - 1;
		size = 0;
	}

	public boolean add(E e) {
		if (size == capacity) {
			reallocate();
		}
		size++;
		rear = (rear + 1) % capacity;
		theData[rear] = e;
		return true;
	}
	
	public E element() {
		if (size == 0) throw new NoSuchElementException();
		return theData[front];
	}
	
	public boolean offer(E e) {
		if (size == capacity) {
			reallocate();
		}
		size++;
		rear = (rear + 1) % capacity;
		theData[rear] = e;
		return true;
	}
	
	public E peek() {
		if (theData[front] == null) return null;
		return theData[front];
	}
	
	public E poll() {
		if (size == 0) return null;
		E result = theData[front];
		front = (front + 1) % capacity;
		size--;
		return result;
	}
	
	public E remove() {
		if (size == 0) throw new NoSuchElementException();
		E temp = theData[front];
		theData[front] = null;
		front = (front + 1) % capacity;
		size--;
		return temp;
	}
	
	private void reallocate() {
		int newCapacity = 2 * capacity;
		E[] newData = (E[]) new Object[newCapacity];
		int j = front;
		for (int i = 0; i < size; i++) {
			newData[i] = theData[j];
			j = (j+1) % capacity;
		}
		front = 0;
		rear = size - 1;
		capacity = newCapacity;
		theData = newData;
	}

	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
}
