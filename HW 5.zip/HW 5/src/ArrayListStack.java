import java.util.ArrayList;
import java.util.EmptyStackException;

public class ArrayListStack<E> implements StackInterface<E> {
	
    	private ArrayList<E> theData = new ArrayList<E>();
    	private int topOfStack = -1;
    	
    	public boolean empty() {
    		if (topOfStack == -1) return true;
    		return false;
    	}
	 
    	public E peek() {
    		if (empty()) {
    			throw new EmptyStackException();
    		}
    		return theData.get(topOfStack);
    	}
	 
    	public E pop() {
    		if (empty()) {
    			throw new EmptyStackException();
    		} 
    		E temp = theData.get(topOfStack);
    		theData.remove(topOfStack);
    		topOfStack--;
    		return temp;
    	}
	 
    	public E push(E obj) {
    		topOfStack++;
    		theData.add(obj);
    		return obj;
    	}
    	
    	public int size() {
    		return topOfStack + 1;
    	}
    	
    	
    }