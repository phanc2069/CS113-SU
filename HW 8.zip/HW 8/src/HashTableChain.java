import java.util.*;

/**
 * HashTable implementation using chaining to tack a pair of key and value pairs.
 * @param <K> Generic Key
 * @param <V> Generic Value
 */
public class HashTableChain<K, V> implements Map<K, V>  {

    private LinkedList<Entry<K, V>>[] table ;
    private  int numKeys ;
    private static final int CAPACITY = 101 ;
    private static final double LOAD_THRESHOLD = 1.5 ;

    ///////////// ENTRY CLASS ///////////////////////////////////////

    /**
     * Contains key-value pairs for HashTable
     * @param <K> the key
     * @param <V> the value
     */
    private static class Entry<K, V> implements Map.Entry<K, V>{
        private K key ;
        private V value ;

        /**
         * Creates a new key-value pair
         * @param key the key
         * @param value the value
         */
        public Entry(K key, V value) {
            this.key = key ;
            this.value = value ;
        }

        /**
         * Returns the key
         * @return the key
         */
        public K getKey() {
            return  key;
        }

        /**
         * Returns the value
         * @return the value
         */
        public V getValue() {
            return value ;
        }

        /**
         * Sets the value
         * @param val the new value
         * @return the old value
         */
        public V setValue(V val) {
            V oldVal = value;
            value = val ;
            return oldVal ;
        }
        @Override
        public String toString() {
            return  key + "=" + value  ;
        }
    }

    ////////////// end Entry Class /////////////////////////////////

    ////////////// EntrySet Class //////////////////////////////////

    /**
     * Inner class to implement set view
     */
    private class EntrySet extends AbstractSet<Map.Entry<K, V>> {


        @Override
        public Iterator<Map.Entry<K, V>> iterator() {
            return new SetIterator();
        }

        @Override
        public int size() {
            return numKeys ;
        }
    }

    ////////////// end EntrySet Class //////////////////////////////

    //////////////   SetIterator Class ////////////////////////////

    /**
     * Class that iterates over the table. Index is table location
     * and lastItemReturned is entry
     */
    private class SetIterator implements Iterator<Map.Entry<K, V>> {

        private int index = 0 ;
        private Entry<K,V> lastItemReturned = null;
        private Iterator<Entry<K, V>> iter = null;

        @Override
        public boolean hasNext() {
        	// FILL HERE
        	if (iter != null && iter.hasNext()) {
        		return true;
        	}
        	do {
        		index++;
        		if (index >= table.length) {
        			return false;
        		}
        	} while (table[index] == null);
        		iter = table[index].iterator();
        		return iter.hasNext();
        }

        @Override
        public Map.Entry<K, V> next() {
        	// FILL HERE
        	if (hasNext()) {
        		lastItemReturned = iter.next();
        		return lastItemReturned;
        	} else {
        		return null;
        	}
        }

        @Override
        public void remove() {
        	// FILL HERE
        	if (lastItemReturned == null) {
        		throw new NoSuchElementException();
        	} else {
        		iter.remove();
        		lastItemReturned = null;
        	}
        }
    }

    ////////////// end SetIterator Class ////////////////////////////

    /**
     * Default constructor, sets the table to initial capacity size
     */
    public HashTableChain() {
        table = new LinkedList[CAPACITY];
    }

    // returns number of keys
    @Override
    public int size() {
        return numKeys;
    }

    // returns boolean if table has no keys
    @Override
    public boolean isEmpty() {
    	// FILL HERE
    	if(numKeys == 0) return true;
    	return false;
    }

    // returns boolean if table has the searched for key
    @Override
    public boolean containsKey(Object key) {
    	// Fill Here
    	for (int index = 0; index < table.length; index++) {
    		if (table[index] != null) {
	    		for (Entry<K, V> nextItem : table[index]) {
	    			if (nextItem != null) {
	    				if (nextItem.getKey().equals(key)) {
	       				return true;
	    				}
	    			}
	   	 		}
    		}
    	}
    	return false;
    }

    // returns boolean if table has the searched for value
    @Override
    public boolean containsValue(Object value) {
    	// FILL HERE
    	for (int index = 0; index < table.length; index++) {
    		if (table[index] != null) {
	    		for (Entry<K, V> nextItem : table[index]) {
	    			if (nextItem != null) {
	    				if (get(nextItem.getKey()).equals(value)) {
	       				return true;
	    				}
	    			}
	   	 		}
    		}
    	}
    	return false;
    }

    // returns Value if table has the searched for key
    @Override
    public V get(Object key) {
    	int index = key.hashCode() % table.length;
    	 if (index < 0) index += table.length;
    	 if (table[index] == null)
    	 return null;
    	 
    	 for (Entry<K, V> nextItem : table[index]) {
    		 if (nextItem.getKey().equals(key))
    		 return nextItem.getValue();
    	 }
    	 return null;
    }

    // adds the key and value pair to the table using hashing
    @Override
    public V put(K key, V value) {
    	int index = key.hashCode() % table.length;
    	if (index < 0) index += table.length;
    	if (table[index] == null) {
    	// Create a new linked list at table[index].
    		table[index] = new LinkedList<>();
    	}
    	for (Entry<K, V> nextItem : table[index]) {
    		if (nextItem.getKey().equals(key)) {
    			// Replace value for this key.
    			V oldVal = nextItem.getValue();
    			nextItem.setValue(value);
    			return oldVal; 
    		}
    	}
    	table[index].addFirst(new Entry<>(key, value));
    	numKeys++;
    	if (numKeys > (LOAD_THRESHOLD * table.length)) rehash();
    	return null;

    }


    /**
     * Resizes the table to be 2X +1 bigger than previous
     */
    private void rehash() {
    	// FILL HERE
    	int newCapacity = 2 * CAPACITY + 1;
    	
    	LinkedList<Entry<K, V>>[] temp = new LinkedList[newCapacity];
    	for (int i = 0; i < newCapacity; i++) temp[i] = null;
    	for (int j = 0; j < table.length; j++) temp[j] = table[j];
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder() ;
        for (int i = 0 ; i < table.length ; i++ ) {
            if (table[i] != null) {
                for (Entry<K, V> nextItem : table[i]) {
                    sb.append(nextItem.toString() + " ") ;
                }
                sb.append(" ");
            }
        }
        return sb.toString() ;

    }

    // remove an entry at the key location
    // return removed value
    @Override
    public V remove(Object key) {
    	int index = key.hashCode() % table.length;
    	Entry<K, V> temp = null;
    	if (index < 0) index += table.length;
    	if (table[index] == null) return null;
    	for (Entry<K, V> nextItem : table[index]) {
   			if (nextItem.getKey().equals(key)) {
   				temp = nextItem;
   				table[index].remove(nextItem);
   				numKeys--;
   			}
   			if (table[index].size() == 0) table[index] = null;
   	 	}
    	if (temp == null) return null;
    	return temp.getValue();
    }

    // throws UnsupportedOperationException
    @Override
    public void putAll(Map<? extends K, ? extends V> m) {
        throw new UnsupportedOperationException() ;
    }

    // empties the table
    @Override
    public void clear() {
    	// Fill HERE
    	SetIterator key = new SetIterator();
    	int SIZE = table.length;
    	if (SIZE != 0) {
    		while (key.hasNext()) {
    			if (key.next() != null) key.remove();
    		}
    	}
    	numKeys = 0;
    }

    // returns a view of the keys in set view
    @Override
    public Set<K> keySet() {
    	// FILL HERE
    	Set<K> temp = new LinkedHashSet<K>(CAPACITY);
    	SetIterator key = new SetIterator();
    	for (int i = 0; i < table.length; i++) {
    		Map.Entry<K,V> check = key.next();
    		if (check != null) temp.add(check.getKey());
    	}
    	return temp;
    }

    // throws UnsupportedOperationException
    @Override
    public Collection<V> values() {
        throw new UnsupportedOperationException() ;
    }


    // returns a set view of the hash table
    @Override
    public Set<Map.Entry<K, V>> entrySet() {
    	// FILL HERE
    	Set<Map.Entry<K, V>> temp = new LinkedHashSet<Map.Entry<K, V>>(CAPACITY);
    	SetIterator key = new SetIterator();
    	for (int i = 0; i < table.length; i++) {
    		Map.Entry<K,V> check = key.next();
    		if (check != null) temp.add(check);
    	}
    	return temp;
    }

    @Override
    public boolean equals(Object o) {
    	Map<K,V> temp = (Map<K,V>) o;
    	if (!(temp.entrySet().equals(entrySet()))) {
    		return false;
    	}
    	return true;
    }

    @Override
    public int hashCode() {
    	int output = 0;
    	SetIterator key = new SetIterator();
    	for (int i = 0; i < table.length; i++) {
    		Map.Entry<K,V> check = key.next();
    		if (check != null) {
    			output += check.getKey().hashCode();
    			output += check.getValue().hashCode();
    		}
    	}
    	return output;
    }
}