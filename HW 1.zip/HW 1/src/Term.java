public class Term extends Object {
	
	private int coef;
	private int expo;
	
	//constructors
	
	public Term() {
		this.setAll(1, 1);
	}
	
	public Term(int c, int e) {
		this.setAll(c, e);
	}
	
	public Term(Term t) {
		if (t == null) throw new NullPointerException();
		else this.setAll(t.getCoefficient(), t.getExponent());
	}
	
	public Term(String s) {
		if (s.length() < 1) this.setAll(0, 0);
		int x = findx(s);
		if(x == -1) { //x doesn't exist (x^0)
			if (s.charAt(0) == '-') { //neg version
					if (s.charAt(1) == 'x') this.setAll(1, 0);
					else {
						int negX = Integer.parseInt(s.substring(1)) * -1;
						this.setAll(negX, 0);
					}
				} //pos version
			else {
				if (s.charAt(1) == 'x') this.setAll(-1, 0);
				else {
					int posX = Integer.parseInt(s.substring(1));
					this.setAll(posX, 0);
				}
			}
		}
		else if (x == s.length()-1) { //x is at the end of the string (x^1)
			if (s.charAt(0) == '-') { //neg version
				if (s.charAt(1) == 'x') this.setAll(-1, 1);
				else {
					int negX = Integer.parseInt(s.substring(1,x)) * -1;
					this.setAll(negX, 1);
				}
				
			} //pos version
			else {
				if (s.charAt(1) == 'x') this.setAll(1, 1);
				else {
					int posX = Integer.parseInt(s.substring(1,x));
					this.setAll(posX, 1);
				}
				
			}
		}
		else { //x is raised to a power not equal to 1 or 0
			if (s.charAt(0) == '-') { //neg version
				if (s.charAt(1) == 'x') {
					int negX = Integer.parseInt(s.substring(x+2));
					this.setAll(-1, negX);
				}
				else {
					int negX = Integer.parseInt(s.substring(1,x)) * -1;
					int Expo = Integer.parseInt(s.substring(x+2));
					this.setAll(negX, Expo);
				}
				
			} //pos version
			else {
				if (s.charAt(1) == 'x') {
					int posExpo = Integer.parseInt(s.substring(x+2));
					this.setAll(1, posExpo);
				}
				else {
					int posCoef = Integer.parseInt(s.substring(1,x));
					int Expo = Integer.parseInt(s.substring(x+2));
					this.setAll(posCoef, Expo);
				}
				
			}
		}
			
	}
	
	public int findx (String s) {
		for(int i = 0; i < s.toString().length(); i++) {
			if (s.charAt(i) == 'x') return i; //wouldn't work if x is the last, but with the format of the Term class toString(), this is not possible
		}
		return -1;
	}
	
	//setters
	
	public boolean setAll(int c, int e) {
		return this.setCoefficient(c) && this.setExponent(e);
	}
	
	public boolean setCoefficient(int c) {
		this.coef = c;
		return true;
	}
	
	public boolean setExponent(int e) {
		this.expo = e;
		return true;
	}
	
	//getters
	
	public int getCoefficient() {
		return this.coef;
	}
	
	public int getExponent() {
		return this.expo;
	}
	
	public int compareTo(Term t) {
		if (t.getCoefficient() == this.getCoefficient() && t.getExponent() == this.getExponent()) return 0;
		else if (t.getExponent() < this.getExponent()) return 1;
		else return -1;
	}
	
	public boolean equals(Object t1) {
		Term t2 = (Term)t1;
		return (t2.getCoefficient() == this.getCoefficient() && t2.getExponent() == this.getExponent());
	}
	
	public Term clone() {
		Term output = new Term(this.getCoefficient(),this.getExponent());
		return output;
	}
	
	public boolean isEmpty() {
		return this.toString().equals("");
	}
	
	
	//toString
	
	public String toString() {
		if (this.coef == 0) return "";
		else if (this.expo == 0 && this.coef > 0) return "+" + this.coef;
		else if (this.expo == 0 && this.coef < 0) return "" + this.coef;
		else if (this.expo == 1 && this.coef == 1) return "+x";
		else if (this.expo == 1 && this.coef == -1) return "-x";
		else if (this.expo == 1 && this.coef > 0) return "+" + this.coef + "x";
		else if (this.expo == 1 && this.coef < 0) return "" + this.coef + "x";
		else if (this.coef == 1) return "+x^"+ this.expo;
		else if (this.coef == -1) return "-x^" + this.expo ;
		else if (coef > 0) return "+" + this.coef + "x^" + this.expo;
		return this.coef + "x^" + this.expo;
	}


}