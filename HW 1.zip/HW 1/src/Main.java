//import java.util.*;

public class Main {
	public static void main(String[] args) {
		//Scanner input = new Scanner(System.in); USED FOR CREATING THE MENU IN CONSOLE
		
		Polynomial t1 = new Polynomial();
		Polynomial t2 = new Polynomial();
	
		Term t = new Term(5, 7);
		Term ttwo = new Term(5, 9);
		Term t3 = new Term(-2, 2);
		Term t4 = new Term(-4, -3);
		
		
		Term t5 = new Term(15, 5);
		Term t6 = new Term(145, 9);
		Term t7 = new Term(-5, 7);
		
		t1.addTerm(t);
		t1.addTerm(ttwo);
		t1.addTerm(t3);
		t1.addTerm(t4);
		t2.addTerm(t5);
		t2.addTerm(t6);
		t2.addTerm(t7);
		
		t1.add(t2);
		
		System.out.println(t1.getList());
	}
	
}