import java.util.*;

public class Main {
	public static void main(String[] args) {
		Boolean con = true;
		Scanner keyboard = new Scanner(System.in); //USED FOR CREATING THE MENU IN CONSOLE
		Polynomial t1 = new Polynomial(), t2 = new Polynomial(), temp = new Polynomial();
		int choice = 0;
		
		while(con) {
			System.out.println("\nMAIN MENU\nWhat would you like to do?\n");
			System.out.println("\t1) Edit the First Polynomial \n \t2) Edit the Second Polynomial \n\t3) Add the Polynomials \n\t4) Exit \n");
			choice = keyboard.nextInt();
			
			if (choice == 1) {
				boolean choice1 = true;
				int con1, poly1Co, poly1Ex;
				while (choice1) {
					System.out.println("\nEnter a Coefficent\n");
					poly1Co = keyboard.nextInt();
					System.out.println("\nEnter a Exponent\n");
					poly1Ex = keyboard.nextInt();
					t1.addTerm(new Term(poly1Co, poly1Ex));
					
					System.out.println("Your current polynomial is:" + t1.toString());
					
					System.out.println("\nWould you like to add another Term?");
					System.out.println("\t1) Yes \n\t2) No\n");
					con1 = keyboard.nextInt();
					if (con1 == 1) {}
					else if (con1 == 2) {
						choice1 = false;
					}
					else {
						boolean badinput = true;
						while (badinput) {
							System.out.println("\nWould you like to add another Term?");
							System.out.println("\t1) Yes \n\t2) No\n");
							con1 = keyboard.nextInt();
							if (con1 == 1) badinput = false;
							if (con1 == 2) {
								choice1 = false;
								badinput = false;
							}
						}
					}
				}
			}
			if (choice == 2) {
				boolean choice2 = true;
				int con2, poly2Co, poly2Ex;
				while (choice2) {
					System.out.println("\nEnter a Coefficent\n");
					poly2Co = keyboard.nextInt();
					System.out.println("\nEnter a Exponent\n");
					poly2Ex = keyboard.nextInt();
					t2.addTerm(new Term(poly2Co, poly2Ex));
					
					System.out.println("Your current polynomial is:" + t2.toString());
					
					System.out.println("\nWould you like to add another Term?");
					System.out.println("\t1) Yes \n\t2) No\n");
					con2 = keyboard.nextInt();
					if (con2 == 1) {}
					else if (con2 == 2) {
						choice2 = false;
					}
					else {
						boolean badinput = true;
						while (badinput) {
							System.out.println("\nWould you like to add another Term?");
							System.out.println("\t1) Yes \n\t2) No\n");
							con2 = keyboard.nextInt();
							if (con2 == 1) badinput = false;
							if (con2 == 2) {
								choice2 = false;
								badinput = false;
							}
						}
					}
				}
			}
			
			if (choice == 3) {
				if (t1.getNumTerms() != 0 && t2.getNumTerms() != 0) {
					temp = t1;
					temp.add(t2);
					System.out.println(temp.toString());
				}
				else System.out.println("Polynomial 1 or 2 is empty!");
			}
			if (choice == 4) {
				con = false;
			}
		}
		System.out.println("Shutting Down...");
	}
}
	