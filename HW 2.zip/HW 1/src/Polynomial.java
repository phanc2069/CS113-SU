import java.util.*;
import junit.framework.*;

public class Polynomial {
	
	private ArrayList<Term> poly = new ArrayList<Term>();
	boolean used = false;
	
	public Polynomial() {
		
	}
	
	public Polynomial(Polynomial p) {
		if (p == null) throw new NullPointerException();
		for(int i = 0; i < p.getList().size(); i++) {
			poly.add(new Term(p.getTerm(i)));
		}
		this.sortPoly();
	}
	
	public boolean addTerm(Term t) {
		if (t == null) return false;
		this.checkEx(t);
		this.sortPoly();
		return true;
	}
	
	public void add(Polynomial p) {
		for(int i = 0; i < p.getList().size(); i++) {
			this.addTerm(p.getTerm(i));
		}
		smallerPoly();
	}
	
	public void clear() {
		poly.clear();
	}
	
	public Term getTerm(int i) {
		return poly.get(i);
	}
	
	public int getNumTerms() {
		return poly.size();
	}
	
	public ArrayList getList() {
		return poly;
	}
	
	//helper method
	
	public void checkEx(Term t) {
		boolean same = false;
		if (used == false) {
			poly.add(t);
			used = true;
		}
		else {
			for(int i = 0; i < poly.size(); i++) {
				if (poly.get(i).getExponent() == t.getExponent()) {
					same = true;
					poly.get(i).setCoefficient(poly.get(i).getCoefficient() + t.getCoefficient());
				}
			}
			if (same == false) poly.add(t);
			
		}
		
	}
	
	public int findx (String s) {
		for(int i = 0; i < s.toString().length(); i++) {
			if (s.charAt(i) == 'x') return i; //wouldn't work if x is the last, but with the format of the Term class toString(), this is not possible
		}
		return -1;
	}
	
	public void sortPoly() {
		if(poly.size() >= 0) {
			ArrayList<Term> temp = new ArrayList<Term>();
		int INITIAL_SIZE = poly.size();
		for (int i = 0; i < INITIAL_SIZE; i++) {
			int tempInt = 0;
			for (int j = 1; j < poly.size(); j++) {
				if (poly.get(j).getExponent() > poly.get(tempInt).getExponent()) {
				tempInt = j;
				}
			}
			temp.add(poly.get(tempInt));
			poly.remove(tempInt);
		}
		poly = temp;
		
		} else System.out.println("Already sorted");
		
	}
	
	public void smallerPoly() {
		for (int i = 0; i < poly.size(); i++) {
			if (poly.get(i).isEmpty()) poly.remove(poly.get(i));
		}
	}
	
	public boolean equals(Object t1) {
		Polynomial t2 = (Polynomial)t1;
		if (t2.getNumTerms() != this.getNumTerms()) return false;
		for(int i = 0; i < t2.getNumTerms(); i++) {
			if (t2.getList().get(i) != this.getList().get(i)) return false;
		}
		return true;
	}
	
	public String toString() {
		if (poly.isEmpty()) return "0";
		String output = poly.get(0).toString().substring(1);
		for (int i = 1; i < poly.size(); i++) {
			output+= " " + poly.get(i);
		}
		return output;
	}
}